package com.aulabd.sitebd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SitebdApplicationTests {

	@Test
	void contextLoads() {
	}

}
