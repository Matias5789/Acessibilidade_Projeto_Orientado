CREATE TABLE IF NOT EXISTS cliente (
     id serial PRIMARY KEY,
     nome  varchar(50),
     cpf   varchar(11)
);